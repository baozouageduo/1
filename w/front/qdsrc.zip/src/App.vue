<!-- src/App.vue -->
<script setup lang="ts">
import BaseLayout from './components/BaseLayout.vue'
</script>

<template>
  <BaseLayout>
    <RouterView />
  </BaseLayout>
</template>
